LOAD 'pg_plan_advice';
SET max_parallel_workers_per_gather = 1;
SET parallel_setup_cost = 0;
SET parallel_tuple_cost = 0;
SET min_parallel_table_scan_size = 0;
SET debug_parallel_query = off;

CREATE TABLE gt_dim (id serial primary key, dim text)
	WITH (autovacuum_enabled = false);
INSERT INTO gt_dim (dim) SELECT random()::text FROM generate_series(1,100) g;
VACUUM ANALYZE gt_dim;

CREATE TABLE gt_fact (
	id int not null,
	dim_id integer not null references gt_dim (id)
) WITH (autovacuum_enabled = false);
INSERT INTO gt_fact
	SELECT g, (g%3)+1 FROM generate_series(1,100000) g;
VACUUM ANALYZE gt_fact;

CREATE TABLE gt_part (id int not null, val int not null)
	PARTITION BY RANGE (id);
CREATE TABLE gt_part1 PARTITION OF gt_part FOR VALUES FROM (0) TO (1000)
	WITH (autovacuum_enabled = false);
CREATE TABLE gt_part2 PARTITION OF gt_part FOR VALUES FROM (1000) TO (2000)
	WITH (autovacuum_enabled = false);
INSERT INTO gt_part SELECT g, g FROM generate_series(0, 1999) g;
VACUUM ANALYZE gt_part;

-- By default, we expect Gather Merge with a parallel hash join.
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;

-- Force Gather or Gather Merge of both relations together.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'gather_merge((f d))';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather((f d))';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
COMMIT;

-- Force a separate Gather or Gather Merge operation for each relation.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'gather_merge(f d)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather(f d)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather((d d/d.d))';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
COMMIT;

-- Force a Gather or Gather Merge on one relation but no parallelism on other.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'gather_merge(f) no_gather(d)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather_merge(d) no_gather(f)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather(f) no_gather(d)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
SET LOCAL pg_plan_advice.advice = 'gather(d) no_gather(f)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
COMMIT;

-- Force no Gather or Gather Merge use at all.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'no_gather(f d)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
COMMIT;

-- Can't force Gather Merge without the ORDER BY clause, but just Gather is OK.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'gather_merge((f d))';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id;
SET LOCAL pg_plan_advice.advice = 'gather((f d))';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id;
COMMIT;

-- Test conflicting advice.
BEGIN;
SET LOCAL pg_plan_advice.advice = 'gather((f d)) no_gather(f)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_fact f JOIN gt_dim d ON f.dim_id = d.id ORDER BY d.id;
COMMIT;

-- Test interaction of NO_GATHER with partitioned tables.  By default, we
-- expect Gather over a Parallel Append, but no_gather(gt_part) should
-- suppress it, even if we prune down to a single partition such that the
-- Append itself doesn't appear in the plan. Previously, we had a bug where
-- NO_GATHER for the parent was omitted from the generated output even when
-- NO_GATHER was supplied, so this also serves to verify that this is no
-- longer happening.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_part WHERE val = 42;
SET LOCAL pg_plan_advice.advice = 'no_gather(gt_part)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_part WHERE val = 42;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT * FROM gt_part WHERE id < 500 AND val = 42;
COMMIT;

-- Test interaction of NO_GATHER with UNION. By default, we expect a
-- Gather over a Parallel Append, but no_gather on the setop arms is
-- enough to suppress it.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION SELECT dim_id FROM gt_fact;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(gt_fact@setop_1 gt_fact@setop_2)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION SELECT dim_id FROM gt_fact;
COMMIT;

-- Test interaction of NO_GATHER with a UNION that has just one surviving
-- arm. In this case, the Append node is elided.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION SELECT dim_id FROM gt_fact WHERE false;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(gt_fact@setop_1)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION SELECT dim_id FROM gt_fact WHERE false;
COMMIT;

-- Test a UNION that has no surviving arms at all. No advice should be
-- generated.
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact WHERE false UNION
	SELECT dim_id FROM gt_fact WHERE false;

-- Test interaction of NO_GATHER with INTERSECT. By default, we expect
-- a HashSetOp with a Gather on each side, but NO_GATHER on the setop arms
-- is enough to suppress it.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact INTERSECT SELECT dim_id FROM gt_fact;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(gt_fact@setop_1 gt_fact@setop_2)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact INTERSECT SELECT dim_id FROM gt_fact;
COMMIT;

-- Test interaction of NO_GATHER with a UNION ALL. This UNION ALL is
-- "flattened" by the planner and the subqueries are pulled up, so the relation
-- identifiers are different from the preceding examples. In this case,
-- we can ask for either a Parallel Append with non-partial children, or
-- suppress Gather and Gather Merge completely.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION ALL SELECT dim_id FROM gt_fact;
SET LOCAL pg_plan_advice.advice = 'GATHER(unnamed_subquery) NO_GATHER(gt_fact gt_fact#2)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION ALL SELECT dim_id FROM gt_fact;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(unnamed_subquery)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
	SELECT dim_id FROM gt_fact UNION ALL SELECT dim_id FROM gt_fact;
COMMIT;

-- Test interaction of NO_GATHER with a UNION ALL that can be flattened,
-- but subqueries that cannot be pulled up. We must use OFFSET '0' here,
-- because writing OFFSET 0 causes the planner to think that the subquery
-- isn't parallel-safe, which is probably something that should be fixed in
-- the core planner. By default, we get a normal Gather over Parallel Append
-- plan, but by varying the advice, we can get a separate Gather over each
-- child, a Parallel Append with a non-partial child, or no parallelism at all.
BEGIN;
EXPLAIN (COSTS OFF, PLAN_ADVICE)
SELECT * FROM (
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') x
	UNION ALL
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') y
) s;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(s)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
SELECT * FROM (
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') x
	UNION ALL
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') y
) s;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(gt_fact@x)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
SELECT * FROM (
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') x
	UNION ALL
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') y
) s;
SET LOCAL pg_plan_advice.advice = 'NO_GATHER(s gt_fact@x gt_fact@y)';
EXPLAIN (COSTS OFF, PLAN_ADVICE)
SELECT * FROM (
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') x
	UNION ALL
	SELECT * FROM (SELECT dim_id FROM gt_fact OFFSET '0') y
) s;
COMMIT;
